<?php
    session_start();
    include_once('header.html');
?>
<?php
    include_once('footer.html');
?>